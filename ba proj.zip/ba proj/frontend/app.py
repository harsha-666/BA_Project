import streamlit as st

# MUST be the first Streamlit command
st.set_page_config(
    page_title="Ride Review Sentiment Dashboard",
    page_icon="🚕",
    layout="wide"
)

import pandas as pd
from textblob import TextBlob
import os
import re
import matplotlib.pyplot as plt
import seaborn as sns
from collections import Counter

from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
from sklearn.linear_model import LinearRegression
from sklearn.tree import DecisionTreeRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.svm import SVR

try:
    import xgboost as xgb
    HAS_XGB = True
except Exception:
    HAS_XGB = False

# ---------------------------
# CONFIG: all your dataset paths
# ---------------------------
DATASETS = {
    "All Apps (Combined)": r"C:\Users\har15\Downloads\ba proj\post-data\All_Final_Graded.xlsx",
    "Ola Only":           r"C:\Users\har15\Downloads\ba proj\post-data\Ola_Final_Graded.xlsx",
    "Uber Only":          r"C:\Users\har15\Downloads\ba proj\post-data\Uber_Final_Graded.xlsx",
    "Rapido Only":        r"C:\Users\har15\Downloads\ba proj\post-data\Rapido1_Final_Graded.xlsx",
}

# ---------------------------
# HELPERS
# ---------------------------
def normalize_text(s: str) -> str:
    if not isinstance(s, str):
        return ""
    s = s.lower().strip()
    s = re.sub(r"\s+", " ", s)
    return s

def score_textblob(comment: str) -> float:
    if not isinstance(comment, str) or not comment.strip():
        return None
    from textblob import TextBlob
    polarity = TextBlob(comment).sentiment.polarity
    score = (polarity + 1.0) * 5.0
    return round(score, 2)

def label_from_score(score: float) -> str:
    if score is None:
        return "Unknown"
    if 0.0 <= score <= 4.0:
        return "Negative"
    elif 4.1 <= score <= 6.0:
        return "Neutral"
    else:
        return "Positive"

@st.cache_data
def load_data(path):
    if not os.path.exists(path):
        return None, None
    df = pd.read_excel(path)

    if 'Comment' not in df.columns:
        raise ValueError(f"No 'Comment' column found in {path}")
    df['Comment'] = df['Comment'].astype(str)

    if 'Cleaned_Comment' not in df.columns:
        df['Cleaned_Comment'] = df['Comment'].str.lower()
    else:
        df['Cleaned_Comment'] = df['Cleaned_Comment'].fillna("").astype(str)

    if 'comment_length' not in df.columns:
        df['comment_length'] = df['Comment'].fillna("").map(len)

    label_col = None
    for c in ['Sentiment_Label_0_10', 'Sentiment_Label_Hybrid', 'Sentiment_Label']:
        if c in df.columns:
            label_col = c
            break

    return df, label_col

@st.cache_resource
def train_models_for_comparison(df_in: pd.DataFrame):
    if 'Score_0_10' not in df_in.columns:
        return None, None, None, None

    dfm = df_in.copy()
    if 'comment_length' not in dfm.columns:
        dfm['comment_length'] = dfm['Comment'].fillna("").map(len)

    X = dfm[['comment_length']]
    y = dfm['Score_0_10']

    mask = X['comment_length'].notna() & y.notna()
    X = X[mask]
    y = y[mask]

    if len(X) < 50:
        return None, None, None, None

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42
    )

    models = {
        'Linear Regression': LinearRegression(),
        'Decision Tree': DecisionTreeRegressor(random_state=42),
        'Support Vector Regressor': SVR(),
        'Random Forest': RandomForestRegressor(random_state=42),
    }
    if HAS_XGB:
        models['XGBoost Regressor'] = xgb.XGBRegressor(
            objective='reg:squarederror',
            random_state=42,
            n_estimators=150,
            max_depth=4
        )

    results = []
    best_name = None
    best_mse = float('inf')
    best_y_test = None
    best_y_pred = None

    for name, model in models.items():
        model.fit(X_train, y_train)
        y_pred = model.predict(X_test)
        mse = mean_squared_error(y_test, y_pred)
        results.append((name, mse))
        if mse < best_mse:
            best_mse = mse
            best_name = name
            best_y_test = y_test
            best_y_pred = y_pred

    results_df = pd.DataFrame(results, columns=['Model', 'MSE']).sort_values('MSE')
    return results_df, best_name, best_y_test, best_y_pred

# ---------------------------
# SIDEBAR: choose dataset & page
# ---------------------------
st.sidebar.title("🚕 Sentiment Dashboard")

dataset_name = st.sidebar.selectbox(
    "Choose dataset:",
    list(DATASETS.keys())
)

page = st.sidebar.radio(
    "Go to:",
    ["Sentiment Checker", "Dataset Overview", "Sentiment Distribution", "Top Words", "Model Comparison"]
)

data_path = DATASETS[dataset_name]
df, label_col = load_data(data_path)

if df is None:
    st.error(f"Dataset not found at: {data_path}")
    st.stop()

# lookup for this dataset
lookup = {}
for _, row in df.iterrows():
    norm = normalize_text(row['Comment'])
    if norm not in lookup:
        lookup[norm] = row

# ---------------------------
# PAGE LOGIC
# ---------------------------

if page == "Sentiment Checker":
    st.title(f"🚕 Sentiment Checker – {dataset_name}")
    st.write("Enter a review and see whether it is **Positive**, **Neutral**, or **Negative**.")

    user_input = st.text_area(
        "Paste or type a review here:",
        height=150,
        placeholder="Example: The driver was very polite and the ride was smooth..."
    )

    if st.button("Analyze Sentiment"):
        if not user_input.strip():
            st.warning("Please enter a review.")
        else:
            norm_input = normalize_text(user_input)

            if norm_input in lookup and label_col is not None:
                row = lookup[norm_input]
                existing_label = str(row[label_col])
                existing_score = row['Score_0_10'] if 'Score_0_10' in row.index else None

                st.success("✅ Exact match found in existing dataset.")
                st.write(f"**Stored Sentiment Label:** `{existing_label}`")
                if existing_score is not None and not pd.isna(existing_score):
                    st.write(f"**Stored Sentiment Score (0–10):** `{existing_score}`")
            else:
                score = score_textblob(user_input)
                label = label_from_score(score)
                st.info("ℹ️ Exact match not found — using on-the-fly scoring.")
                st.write(f"**Predicted Sentiment:** `{label}`")
                st.write(f"**Predicted Score (0–10):** `{score}`")

    with st.expander("Show sample from this dataset"):
        sample_cols = ['Comment']
        if label_col is not None:
            sample_cols.append(label_col)
        if 'Score_0_10' in df.columns:
            sample_cols.append('Score_0_10')
        st.dataframe(df[sample_cols].head(20))

elif page == "Dataset Overview":
    st.title(f"📊 Dataset Overview – {dataset_name}")

    c1, c2 = st.columns(2)
    with c1:
        st.write("**Number of rows:**", len(df))
        st.write("**Number of columns:**", len(df.columns))
    with c2:
        if 'Source_File' in df.columns:
            st.write("**Source breakdown:**")
            st.write(df['Source_File'].value_counts())
        else:
            st.write("No Source_File column.")

    st.subheader("Columns")
    st.write(list(df.columns))

    st.subheader("Sample Records")
    st.dataframe(df.head(10))

    numeric_cols = [c for c in df.columns if str(df[c].dtype) in ('int64','float64')]
    if numeric_cols:
        st.subheader("Numeric Summary")
        st.dataframe(df[numeric_cols].describe().round(2))

elif page == "Sentiment Distribution":
    st.title(f"🎯 Sentiment Distribution – {dataset_name}")

    if label_col is not None:
        st.subheader("Sentiment Label Counts")
        label_counts = df[label_col].value_counts(dropna=False)
        st.write(label_counts)

        fig, ax = plt.subplots(figsize=(5,4))
        sns.barplot(x=label_counts.index, y=label_counts.values, ax=ax)
        ax.set_xlabel("Sentiment Label")
        ax.set_ylabel("Count")
        ax.set_title("Distribution of Sentiment Labels")
        st.pyplot(fig)
    else:
        st.warning("No sentiment label column (e.g., Sentiment_Label_0_10).")

    score_cols = [c for c in ['Score_0_10','Pos_Score_0_10','Neu_Score_0_10','Neg_Score_0_10'] if c in df.columns]
    if score_cols:
        st.subheader("Average Sentiment Scores (0–10)")
        avg_scores = df[score_cols].mean().round(2)
        st.write(avg_scores)

        fig2, ax2 = plt.subplots(figsize=(6,4))
        sns.barplot(x=avg_scores.index, y=avg_scores.values, ax=ax2)
        ax2.set_ylim(0,10)
        ax2.set_ylabel("Average Score (0–10)")
        ax2.set_title("Average Sentiment Scores")
        st.pyplot(fig2)

    if 'comment_length' in df.columns:
        st.subheader("Comment Length Distribution")
        fig3, ax3 = plt.subplots(figsize=(6,4))
        sns.histplot(df['comment_length'], bins=30, kde=True, ax=ax3)
        ax3.set_xlabel("Comment Length (characters)")
        st.pyplot(fig3)

elif page == "Top Words":
    st.title(f"📝 Top Words – {dataset_name}")

    if label_col is not None:
        sentiment_filter = st.selectbox(
            "Filter by sentiment (optional):",
            options=["All"] + sorted(df[label_col].dropna().unique().tolist())
        )
    else:
        sentiment_filter = "All"

    if sentiment_filter != "All" and label_col is not None:
        subset = df[df[label_col] == sentiment_filter]
    else:
        subset = df

    if subset.empty:
        st.warning("No data for this selection.")
    else:
        all_words = " ".join(subset['Cleaned_Comment'].astype(str)).split()
        all_words = [w for w in all_words if len(w) > 2]
        word_counts = Counter(all_words)
        top_n = st.slider("Number of top words to show:", 10, 50, 20)
        most_common = word_counts.most_common(top_n)

        if not most_common:
            st.warning("No words after filtering.")
        else:
            words_df = pd.DataFrame(most_common, columns=['word','count'])
            st.dataframe(words_df)

            fig4, ax4 = plt.subplots(figsize=(8,5))
            sns.barplot(data=words_df, x='count', y='word', ax=ax4)
            ax4.set_xlabel("Count")
            ax4.set_ylabel("Word")
            ax4.set_title(f"Top {top_n} Words" + ("" if sentiment_filter=="All" else f" ({sentiment_filter})"))
            st.pyplot(fig4)

elif page == "Model Comparison":
    st.title(f"📉 Model Comparison – {dataset_name}")
    st.write(
        "Models predict the **overall sentiment score (Score_0_10)** "
        "from **comment length**. This mirrors your predictive modeling."
    )

    results_df, best_name, y_test, y_pred = train_models_for_comparison(df)

    if results_df is None or best_name is None:
        st.warning("Not enough data or missing Score_0_10/comment_length for modeling.")
    else:
        st.subheader("Model Performance (Mean Squared Error)")
        st.dataframe(results_df.reset_index(drop=True))

        fig_m, ax_m = plt.subplots(figsize=(7,4))
        sns.barplot(data=results_df, x='MSE', y='Model', ax=ax_m)
        ax_m.set_title("Model Comparison (Lower MSE = Better)")
        st.pyplot(fig_m)

        st.success(f"Best Performing Model: **{best_name}**")

        residuals = y_test - y_pred
        st.subheader("Residual Plot (Best Model)")
        fig_r, ax_r = plt.subplots(figsize=(6,4))
        ax_r.scatter(y_pred, residuals, alpha=0.5)
        ax_r.axhline(0, color='red', linestyle='--')
        ax_r.set_xlabel("Predicted Score")
        ax_r.set_ylabel("Residual (Actual - Predicted)")
        st.pyplot(fig_r)

        st.subheader("Predicted vs Actual (Best Model)")
        fig_pa, ax_pa = plt.subplots(figsize=(6,4))
        ax_pa.scatter(y_test, y_pred, alpha=0.5)
        line_min = min(y_test.min(), min(y_pred))
        line_max = max(y_test.max(), max(y_pred))
        ax_pa.plot([line_min, line_max], [line_min, line_max], 'r--')
        ax_pa.set_xlabel("Actual Score")
        ax_pa.set_ylabel("Predicted Score")
        st.pyplot(fig_pa)
